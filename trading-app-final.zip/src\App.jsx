import React, { useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import Layout from './pages/entities/layout.jsx'
import Dashboard from './pages/dashboard.jsx'
import AddTrade from './pages/addtrade.js'
import { initializeSampleData } from './data/sample-trades.js'

function App() {
  useEffect(() => {
    // Initialize sample data on first load
    initializeSampleData()
  }, [])

  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/add-trade" element={<AddTrade />} />
      </Routes>
    </Layout>
  )
}

export default App
